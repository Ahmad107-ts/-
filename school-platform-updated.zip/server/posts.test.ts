import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createMockContext(role: "admin" | "teacher" | "student" = "teacher"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-123",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const ctx = createMockContext("teacher");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();
    expect(result).toBeDefined();
    expect(result?.email).toBe("test@example.com");
    expect(result?.role).toBe("teacher");
  });
});

describe("posts procedures", () => {
  it("allows public access to posts.getAll", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // This should not throw - public access is allowed
    const result = await caller.posts.getAll({});
    expect(Array.isArray(result)).toBe(true);
  });

  it("requires authentication for posts.create", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.posts.create({
        title: "Test Post",
        content: "Test content",
        category: "announcement",
      })
    ).rejects.toThrow();
  });

  it("requires teacher or admin role for posts.create", async () => {
    const ctx = createMockContext("student");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.posts.create({
        title: "Test Post",
        content: "Test content",
        category: "announcement",
      })
    ).rejects.toThrow("Teacher or Admin access required");
  });
});

describe("users procedures", () => {
  it("requires admin role for users.getAll", async () => {
    const ctx = createMockContext("teacher");
    const caller = appRouter.createCaller(ctx);

    await expect(caller.users.getAll({})).rejects.toThrow("Admin access required");
  });

  it("requires admin role for users.updateRole", async () => {
    const ctx = createMockContext("teacher");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.users.updateRole({ userId: 2, role: "student" })
    ).rejects.toThrow("Admin access required");
  });
});

describe("comments procedures", () => {
  it("allows public access to comments.getByPostId", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.comments.getByPostId({ postId: 1 });
    expect(Array.isArray(result)).toBe(true);
  });

  it("requires authentication for comments.create", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.comments.create({ postId: 1, content: "Test comment" })
    ).rejects.toThrow();
  });
});

describe("likes procedures", () => {
  it("requires authentication for likes.toggle", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.likes.toggle({ postId: 1 })).rejects.toThrow();
  });
});

describe("notifications procedures", () => {
  it("requires authentication for notifications.getMine", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.notifications.getMine({})).rejects.toThrow();
  });

  it("requires authentication for notifications.getUnreadCount", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.notifications.getUnreadCount()).rejects.toThrow();
  });
});
