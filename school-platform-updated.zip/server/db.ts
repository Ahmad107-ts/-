import { eq, desc, and, like, sql, or, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  posts, InsertPost, 
  comments, InsertComment,
  likes, InsertLike,
  attachments, InsertAttachment,
  notifications, InsertNotification
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER FUNCTIONS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "bio", "avatarUrl"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers(filters?: { role?: string; search?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(users);
  const conditions = [];

  if (filters?.role && filters.role !== 'all') {
    conditions.push(eq(users.role, filters.role as 'admin' | 'teacher' | 'student'));
  }
  if (filters?.search) {
    conditions.push(
      or(
        like(users.name, `%${filters.search}%`),
        like(users.email, `%${filters.search}%`)
      )
    );
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as typeof query;
  }

  return await query.orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: 'admin' | 'teacher' | 'student') {
  const db = await getDb();
  if (!db) return;

  await db.update(users).set({ role }).where(eq(users.id, userId));
}

export async function updateUserProfile(userId: number, data: { name?: string; bio?: string; avatarUrl?: string }) {
  const db = await getDb();
  if (!db) return;

  await db.update(users).set(data).where(eq(users.id, userId));
}

export async function toggleUserActive(userId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) return;

  await db.update(users).set({ isActive }).where(eq(users.id, userId));
}

// ============ POST FUNCTIONS ============

export async function createPost(post: InsertPost & { audience?: 'admin' | 'teacher' | 'student' | 'all' }) {
  const db = await getDb();
  if (!db) return null;

  const postData = {
    ...post,
    audience: post.audience || 'all'
  };
  const result = await db.insert(posts).values(postData as InsertPost);
  return result[0].insertId;
}

export async function getPostById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(posts).where(eq(posts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getPostWithAuthor(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select({
      post: posts,
      author: {
        id: users.id,
        name: users.name,
        avatarUrl: users.avatarUrl,
        role: users.role,
      }
    })
    .from(posts)
    .leftJoin(users, eq(posts.authorId, users.id))
    .where(eq(posts.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getAllPosts(filters?: { 
  category?: string; 
  authorId?: number; 
  search?: string;
  isPublished?: boolean;
  limit?: number;
  offset?: number;
  audience?: string;
  userRole?: 'admin' | 'teacher' | 'student';
}) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [];

  if (filters?.category && filters.category !== 'all') {
    conditions.push(eq(posts.category, filters.category as any));
  }
  if (filters?.authorId) {
    conditions.push(eq(posts.authorId, filters.authorId));
  }
  if (filters?.search) {
    conditions.push(
      or(
        like(posts.title, `%${filters.search}%`),
        like(posts.content, `%${filters.search}%`)
      )
    );
  }
  if (filters?.isPublished !== undefined) {
    conditions.push(eq(posts.isPublished, filters.isPublished));
  }
  
  // Filter by audience based on user role
  if (filters?.userRole) {
    const audienceConditions = [];
    // Show posts for 'all' audience
    audienceConditions.push(eq(posts.audience, 'all'));
    // Show posts for the user's role
    audienceConditions.push(eq(posts.audience, filters.userRole));
    conditions.push(or(...audienceConditions));
  } else if (filters?.audience) {
    // If specific audience is requested
    conditions.push(eq(posts.audience, filters.audience as any));
  }

  let query = db
    .select({
      post: posts,
      author: {
        id: users.id,
        name: users.name,
        avatarUrl: users.avatarUrl,
        role: users.role,
      }
    })
    .from(posts)
    .leftJoin(users, eq(posts.authorId, users.id));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as typeof query;
  }

  query = query.orderBy(desc(posts.isPinned), desc(posts.createdAt)) as typeof query;

  if (filters?.limit) {
    query = query.limit(filters.limit) as typeof query;
  }
  if (filters?.offset) {
    query = query.offset(filters.offset) as typeof query;
  }

  return await query;
}

export async function updatePost(id: number, data: Partial<InsertPost>) {
  const db = await getDb();
  if (!db) return;

  await db.update(posts).set(data).where(eq(posts.id, id));
}

export async function deletePost(id: number) {
  const db = await getDb();
  if (!db) return;

  // Delete related data first
  await db.delete(comments).where(eq(comments.postId, id));
  await db.delete(likes).where(eq(likes.postId, id));
  await db.delete(attachments).where(eq(attachments.postId, id));
  await db.delete(posts).where(eq(posts.id, id));
}

export async function incrementViewCount(postId: number) {
  const db = await getDb();
  if (!db) return;

  await db.update(posts).set({ viewCount: sql`${posts.viewCount} + 1` }).where(eq(posts.id, postId));
}

// ============ COMMENT FUNCTIONS ============

export async function createComment(comment: InsertComment) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(comments).values(comment);
  return result[0].insertId;
}

export async function getCommentsByPostId(postId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select({
      comment: comments,
      author: {
        id: users.id,
        name: users.name,
        avatarUrl: users.avatarUrl,
        role: users.role,
      }
    })
    .from(comments)
    .leftJoin(users, eq(comments.authorId, users.id))
    .where(eq(comments.postId, postId))
    .orderBy(desc(comments.createdAt));
}

export async function deleteComment(id: number) {
  const db = await getDb();
  if (!db) return;

  await db.delete(comments).where(eq(comments.id, id));
}

export async function toggleCommentApproval(id: number, isApproved: boolean) {
  const db = await getDb();
  if (!db) return;

  await db.update(comments).set({ isApproved }).where(eq(comments.id, id));
}

// ============ LIKE FUNCTIONS ============

export async function toggleLike(postId: number, userId: number) {
  const db = await getDb();
  if (!db) return { liked: false };

  const existing = await db
    .select()
    .from(likes)
    .where(and(eq(likes.postId, postId), eq(likes.userId, userId)))
    .limit(1);

  if (existing.length > 0) {
    await db.delete(likes).where(eq(likes.id, existing[0].id));
    return { liked: false };
  } else {
    await db.insert(likes).values({ postId, userId });
    return { liked: true };
  }
}

export async function getLikeCount(postId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(likes)
    .where(eq(likes.postId, postId));

  return result[0]?.count || 0;
}

export async function hasUserLiked(postId: number, userId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(likes)
    .where(and(eq(likes.postId, postId), eq(likes.userId, userId)))
    .limit(1);

  return result.length > 0;
}

export async function getLikesForPosts(postIds: number[], userId?: number) {
  const db = await getDb();
  if (!db || postIds.length === 0) return {};

  const counts = await db
    .select({ 
      postId: likes.postId, 
      count: sql<number>`count(*)` 
    })
    .from(likes)
    .where(inArray(likes.postId, postIds))
    .groupBy(likes.postId);

  const result: Record<number, { count: number; userLiked: boolean }> = {};
  
  for (const postId of postIds) {
    const countData = counts.find(c => c.postId === postId);
    result[postId] = { count: countData?.count || 0, userLiked: false };
  }

  if (userId) {
    const userLikes = await db
      .select({ postId: likes.postId })
      .from(likes)
      .where(and(inArray(likes.postId, postIds), eq(likes.userId, userId)));

    for (const like of userLikes) {
      if (result[like.postId]) {
        result[like.postId].userLiked = true;
      }
    }
  }

  return result;
}

// ============ ATTACHMENT FUNCTIONS ============

export async function createAttachment(attachment: InsertAttachment) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(attachments).values(attachment);
  return result[0].insertId;
}

export async function getAttachmentsByPostId(postId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(attachments).where(eq(attachments.postId, postId));
}

export async function deleteAttachment(id: number) {
  const db = await getDb();
  if (!db) return;

  await db.delete(attachments).where(eq(attachments.id, id));
}

// ============ NOTIFICATION FUNCTIONS ============

export async function createNotification(notification: InsertNotification) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(notifications).values(notification);
  return result[0].insertId;
}

export async function getNotificationsByUserId(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) return;

  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsAsRead(userId: number) {
  const db = await getDb();
  if (!db) return;

  await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));

  return result[0]?.count || 0;
}

export async function getAdminUsers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users).where(eq(users.role, 'admin'));
}

// ============ STATS FUNCTIONS ============

export async function getStats() {
  const db = await getDb();
  if (!db) return { users: 0, posts: 0, comments: 0 };

  const [userCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
  const [postCount] = await db.select({ count: sql<number>`count(*)` }).from(posts);
  const [commentCount] = await db.select({ count: sql<number>`count(*)` }).from(comments);

  return {
    users: userCount?.count || 0,
    posts: postCount?.count || 0,
    comments: commentCount?.count || 0,
  };
}

export async function getCommentCount(postId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(comments)
    .where(eq(comments.postId, postId));

  return result[0]?.count || 0;
}

export async function getCommentsCountForPosts(postIds: number[]) {
  const db = await getDb();
  if (!db || postIds.length === 0) return {};

  const counts = await db
    .select({ 
      postId: comments.postId, 
      count: sql<number>`count(*)` 
    })
    .from(comments)
    .where(inArray(comments.postId, postIds))
    .groupBy(comments.postId);

  const result: Record<number, number> = {};
  for (const postId of postIds) {
    const countData = counts.find(c => c.postId === postId);
    result[postId] = countData?.count || 0;
  }

  return result;
}
