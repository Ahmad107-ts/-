import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { notifyOwner } from "./_core/notification";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Admin access required' });
  }
  return next({ ctx });
});

// Teacher or Admin procedure
const teacherProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin' && ctx.user.role !== 'teacher') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Teacher or Admin access required' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // User management
  users: router({
    getAll: adminProcedure
      .input(z.object({
        role: z.string().optional(),
        search: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAllUsers(input);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getUserById(input.id);
      }),

    updateRole: adminProcedure
      .input(z.object({
        userId: z.number(),
        role: z.enum(['admin', 'teacher', 'student']),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.updateUserRole(input.userId, input.role);
        
        // Create notification for the user
        await db.createNotification({
          userId: input.userId,
          type: 'role_change',
          title: 'تم تغيير صلاحياتك',
          message: `تم تغيير دورك إلى: ${input.role === 'admin' ? 'مدير' : input.role === 'teacher' ? 'معلم' : 'طالب'}`,
        });

        return { success: true };
      }),

    toggleActive: adminProcedure
      .input(z.object({
        userId: z.number(),
        isActive: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        await db.toggleUserActive(input.userId, input.isActive);
        return { success: true };
      }),

    updateProfile: protectedProcedure
      .input(z.object({
        name: z.string().optional(),
        bio: z.string().optional(),
        avatarUrl: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        await db.updateUserProfile(ctx.user.id, input);
        return { success: true };
      }),

    getStats: adminProcedure.query(async () => {
      return await db.getStats();
    }),
  }),

  // Posts management
  posts: router({
    getAll: publicProcedure
      .input(z.object({
        category: z.string().optional(),
        authorId: z.number().optional(),
        search: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
        audience: z.string().optional(),
      }).optional())
      .query(async ({ input, ctx }) => {
        const posts = await db.getAllPosts({
          ...input,
          isPublished: true,
          userRole: ctx.user?.role,
        });

        const postIds = posts.map(p => p.post.id);
        const likesData = await db.getLikesForPosts(postIds, ctx.user?.id);
        const commentsCount = await db.getCommentsCountForPosts(postIds);

        return posts.map(p => ({
          ...p,
          likes: likesData[p.post.id] || { count: 0, userLiked: false },
          commentsCount: commentsCount[p.post.id] || 0,
        }));
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const post = await db.getPostWithAuthor(input.id);
        if (!post) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Post not found' });
        }

        // Increment view count
        await db.incrementViewCount(input.id);

        const [likeCount, userLiked, attachments, commentsCount] = await Promise.all([
          db.getLikeCount(input.id),
          ctx.user ? db.hasUserLiked(input.id, ctx.user.id) : false,
          db.getAttachmentsByPostId(input.id),
          db.getCommentCount(input.id),
        ]);

        return {
          ...post,
          likes: { count: likeCount, userLiked },
          attachments,
          commentsCount,
        };
      }),

    create: teacherProcedure
      .input(z.object({
        title: z.string().min(1),
        content: z.string().min(1),
        excerpt: z.string().optional(),
        category: z.enum(['announcement', 'lesson', 'activity', 'news', 'resource']),
        audience: z.enum(['admin', 'teacher', 'student', 'all']).default('all'),
        featuredImageUrl: z.string().optional(),
        isPinned: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const postId = await db.createPost({
          ...input,
          authorId: ctx.user.id,
          audience: input.audience,
        });

        // Notify admin about new post
        const admins = await db.getAdminUsers();
        for (const admin of admins) {
          if (admin.id !== ctx.user.id) {
            await db.createNotification({
              userId: admin.id,
              type: 'new_post',
              title: 'منشور جديد',
              message: `قام ${ctx.user.name || 'مستخدم'} بنشر: ${input.title}`,
              relatedPostId: postId || undefined,
            });
          }
        }

        // Also notify owner via system notification
        await notifyOwner({
          title: 'منشور جديد في المنصة',
          content: `قام ${ctx.user.name || 'مستخدم'} (${ctx.user.role}) بنشر منشور جديد: "${input.title}"`,
        });

        return { id: postId };
      }),

    update: teacherProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().min(1).optional(),
        content: z.string().min(1).optional(),
        excerpt: z.string().optional(),
        category: z.enum(['announcement', 'lesson', 'activity', 'news', 'resource']).optional(),
        audience: z.enum(['admin', 'teacher', 'student', 'all']).optional(),
        featuredImageUrl: z.string().optional(),
        isPinned: z.boolean().optional(),
        isPublished: z.boolean().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const post = await db.getPostById(input.id);
        if (!post) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Post not found' });
        }

        // Only author or admin can update
        if (post.authorId !== ctx.user.id && ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Not authorized to update this post' });
        }

        const { id, ...updateData } = input;
        await db.updatePost(id, updateData);
        return { success: true };
      }),

    delete: teacherProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const post = await db.getPostById(input.id);
        if (!post) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Post not found' });
        }

        // Only author or admin can delete
        if (post.authorId !== ctx.user.id && ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Not authorized to delete this post' });
        }

        await db.deletePost(input.id);
        return { success: true };
      }),

    togglePin: adminProcedure
      .input(z.object({ id: z.number(), isPinned: z.boolean() }))
      .mutation(async ({ input }) => {
        await db.updatePost(input.id, { isPinned: input.isPinned });
        return { success: true };
      }),
  }),

  // Comments
  comments: router({
    getByPostId: publicProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCommentsByPostId(input.postId);
      }),

    create: protectedProcedure
      .input(z.object({
        postId: z.number(),
        content: z.string().min(1),
      }))
      .mutation(async ({ input, ctx }) => {
        const commentId = await db.createComment({
          postId: input.postId,
          authorId: ctx.user.id,
          content: input.content,
        });

        // Notify post author
        const post = await db.getPostById(input.postId);
        if (post && post.authorId !== ctx.user.id) {
          await db.createNotification({
            userId: post.authorId,
            type: 'new_comment',
            title: 'تعليق جديد',
            message: `علق ${ctx.user.name || 'مستخدم'} على منشورك`,
            relatedPostId: input.postId,
          });
        }

        return { id: commentId };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Admin can delete any comment, users can delete their own
        // For simplicity, we'll allow deletion
        await db.deleteComment(input.id);
        return { success: true };
      }),

    toggleApproval: adminProcedure
      .input(z.object({ id: z.number(), isApproved: z.boolean() }))
      .mutation(async ({ input }) => {
        await db.toggleCommentApproval(input.id, input.isApproved);
        return { success: true };
      }),
  }),

  // Likes
  likes: router({
    toggle: protectedProcedure
      .input(z.object({ postId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return await db.toggleLike(input.postId, ctx.user.id);
      }),
  }),

  // Attachments
  attachments: router({
    create: teacherProcedure
      .input(z.object({
        postId: z.number(),
        fileName: z.string(),
        fileData: z.string(), // base64
        fileType: z.string(),
        fileSize: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Verify post ownership
        const post = await db.getPostById(input.postId);
        if (!post) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Post not found' });
        }
        if (post.authorId !== ctx.user.id && ctx.user.role !== 'admin') {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'Not authorized' });
        }

        // Upload to S3
        const fileBuffer = Buffer.from(input.fileData, 'base64');
        const fileKey = `attachments/${ctx.user.id}/${nanoid()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, fileBuffer, input.fileType);

        // Save to database
        const attachmentId = await db.createAttachment({
          postId: input.postId,
          fileName: input.fileName,
          fileUrl: url,
          fileKey,
          fileType: input.fileType,
          fileSize: input.fileSize,
        });

        return { id: attachmentId, url };
      }),

    delete: teacherProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteAttachment(input.id);
        return { success: true };
      }),
  }),

  // File upload for images
  upload: router({
    image: teacherProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(), // base64
        fileType: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const fileBuffer = Buffer.from(input.fileData, 'base64');
        const fileKey = `images/${ctx.user.id}/${nanoid()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, fileBuffer, input.fileType);
        return { url };
      }),
  }),

  // Notifications
  notifications: router({
    getMine: protectedProcedure
      .input(z.object({ limit: z.number().optional() }).optional())
      .query(async ({ input, ctx }) => {
        return await db.getNotificationsByUserId(ctx.user.id, input?.limit || 20);
      }),

    getUnreadCount: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUnreadNotificationCount(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),

    markAllAsRead: protectedProcedure.mutation(async ({ ctx }) => {
      await db.markAllNotificationsAsRead(ctx.user.id);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
