import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  ArrowRight,
  Calendar,
  Edit,
  FileText,
  Heart,
  Loader2,
  LogOut,
  Mail,
  MessageSquare,
  Settings,
  Shield,
  User,
} from "lucide-react";
import { useState, useEffect } from "react";
import { Link, useLocation, useParams } from "wouter";
import { toast } from "sonner";

const roleLabels: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  admin: { label: "مدير", color: "bg-primary/10 text-primary", icon: <Shield className="h-4 w-4" /> },
  teacher: { label: "معلم", color: "bg-blue-100 text-blue-700", icon: <FileText className="h-4 w-4" /> },
  student: { label: "طالب", color: "bg-emerald-100 text-emerald-700", icon: <User className="h-4 w-4" /> },
};

const categoryLabels: Record<string, { label: string; color: string }> = {
  announcement: { label: "إعلان", color: "bg-red-100 text-red-800" },
  lesson: { label: "درس", color: "bg-blue-100 text-blue-800" },
  activity: { label: "نشاط", color: "bg-green-100 text-green-800" },
  news: { label: "أخبار", color: "bg-purple-100 text-purple-800" },
  resource: { label: "مصدر", color: "bg-amber-100 text-amber-800" },
};

export default function Profile() {
  const { user: currentUser, logout, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams<{ id?: string }>();
  
  const isOwnProfile = !params.id || (currentUser && parseInt(params.id) === currentUser.id);
  const profileUserId = params.id ? parseInt(params.id) : currentUser?.id;

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editName, setEditName] = useState("");
  const [editBio, setEditBio] = useState("");

  const { data: profileUser, isLoading: loadingUser } = trpc.users.getById.useQuery(
    { id: profileUserId! },
    { enabled: !!profileUserId && !isOwnProfile }
  );

  const { data: userPosts, isLoading: loadingPosts } = trpc.posts.getAll.useQuery(
    { authorId: profileUserId },
    { enabled: !!profileUserId }
  );

  const updateProfileMutation = trpc.users.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الملف الشخصي");
      setEditDialogOpen(false);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const user = isOwnProfile ? currentUser : profileUser;

  useEffect(() => {
    if (user) {
      setEditName(user.name || "");
      setEditBio(user.bio || "");
    }
  }, [user]);

  const handleUpdateProfile = () => {
    updateProfileMutation.mutate({
      name: editName,
      bio: editBio,
    });
  };

  // Redirect to login if not authenticated and viewing own profile
  if (!authLoading && !currentUser && isOwnProfile) {
    window.location.href = "/login";
    return null;
  }

  if (authLoading || loadingUser) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4">
        <div className="flex items-center gap-6 mb-8">
          <Skeleton className="h-24 w-24 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <User className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="font-display text-2xl mb-2">المستخدم غير موجود</h2>
          <Button onClick={() => setLocation("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  const role = roleLabels[user.role];

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation("/")}
        className="mb-6 gap-2"
      >
        <ArrowRight className="h-4 w-4" />
        العودة
      </Button>

      {/* Profile Header */}
      <Card className="editorial-card mb-8">
        <CardContent className="pt-8 pb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            {/* Avatar */}
            <Avatar className="h-24 w-24 border-4 border-background shadow-lg">
              <AvatarFallback className="bg-secondary text-3xl font-display">
                {user.name?.charAt(0)?.toUpperCase() || "؟"}
              </AvatarFallback>
            </Avatar>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="font-display text-3xl">{user.name || "بدون اسم"}</h1>
                <Badge className={`${role.color} gap-1`}>
                  {role.icon}
                  {role.label}
                </Badge>
              </div>

              {user.email && (
                <p className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Mail className="h-4 w-4" />
                  <span className="font-sans text-sm">{user.email}</span>
                </p>
              )}

              <p className="flex items-center gap-2 text-muted-foreground text-sm">
                <Calendar className="h-4 w-4" />
                <span className="font-sans">
                  انضم في {new Date(user.createdAt).toLocaleDateString("ar-SA", {
                    year: "numeric",
                    month: "long",
                  })}
                </span>
              </p>

              {user.bio && (
                <p className="mt-4 font-serif text-foreground/80">{user.bio}</p>
              )}
            </div>

            {/* Actions */}
            {isOwnProfile && (
              <div className="flex flex-col gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditDialogOpen(true)}
                  className="gap-2"
                >
                  <Edit className="h-4 w-4" />
                  تعديل الملف
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={logout}
                  className="gap-2 text-destructive hover:text-destructive"
                >
                  <LogOut className="h-4 w-4" />
                  تسجيل الخروج
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="editorial-card">
          <CardContent className="pt-6 text-center">
            <div className="text-3xl font-display text-primary mb-1">
              {userPosts?.length || 0}
            </div>
            <p className="text-sm text-muted-foreground font-sans">منشور</p>
          </CardContent>
        </Card>
        <Card className="editorial-card">
          <CardContent className="pt-6 text-center">
            <div className="text-3xl font-display text-primary mb-1">
              {userPosts?.reduce((acc, p) => acc + p.likes.count, 0) || 0}
            </div>
            <p className="text-sm text-muted-foreground font-sans">إعجاب</p>
          </CardContent>
        </Card>
        <Card className="editorial-card">
          <CardContent className="pt-6 text-center">
            <div className="text-3xl font-display text-primary mb-1">
              {userPosts?.reduce((acc, p) => acc + p.commentsCount, 0) || 0}
            </div>
            <p className="text-sm text-muted-foreground font-sans">تعليق</p>
          </CardContent>
        </Card>
        <Card className="editorial-card">
          <CardContent className="pt-6 text-center">
            <div className="text-3xl font-display text-primary mb-1">
              {userPosts?.reduce((acc, p) => acc + p.post.viewCount, 0) || 0}
            </div>
            <p className="text-sm text-muted-foreground font-sans">مشاهدة</p>
          </CardContent>
        </Card>
      </div>

      {/* User Posts */}
      <section>
        <h2 className="font-display text-2xl mb-6">
          {isOwnProfile ? "منشوراتي" : `منشورات ${user.name}`}
        </h2>

        {loadingPosts ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="editorial-card">
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-3" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : userPosts && userPosts.length > 0 ? (
          <div className="space-y-4">
            {userPosts.map(({ post, likes, commentsCount }) => {
              const category = categoryLabels[post.category];
              return (
                <Link key={post.id} href={`/post/${post.id}`}>
                  <Card className="editorial-card cursor-pointer group">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        {post.featuredImageUrl && (
                          <img
                            src={post.featuredImageUrl}
                            alt={post.title}
                            className="w-24 h-24 object-cover rounded-lg shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={`${category.color} text-xs`}>
                              {category.label}
                            </Badge>
                            <span className="text-xs text-muted-foreground font-sans">
                              {new Date(post.createdAt).toLocaleDateString("ar-SA")}
                            </span>
                          </div>
                          <h3 className="font-display text-lg mb-2 group-hover:text-primary transition-colors line-clamp-1">
                            {post.title}
                          </h3>
                          {post.excerpt && (
                            <p className="font-serif text-sm text-muted-foreground line-clamp-2">
                              {post.excerpt}
                            </p>
                          )}
                          <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Heart className="h-4 w-4" />
                              {likes.count}
                            </span>
                            <span className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              {commentsCount}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        ) : (
          <Card className="editorial-card">
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground font-serif">
                {isOwnProfile
                  ? "لم تقم بنشر أي محتوى بعد"
                  : "لم يقم هذا المستخدم بنشر أي محتوى بعد"}
              </p>
              {isOwnProfile && (user.role === "admin" || user.role === "teacher") && (
                <Button
                  className="mt-4"
                  onClick={() => setLocation("/create")}
                >
                  إنشاء منشور جديد
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </section>

      {/* Edit Profile Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">تعديل الملف الشخصي</DialogTitle>
            <DialogDescription className="font-serif">
              قم بتحديث معلوماتك الشخصية
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="font-sans">الاسم</Label>
              <Input
                id="name"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="أدخل اسمك"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bio" className="font-sans">نبذة عنك</Label>
              <Textarea
                id="bio"
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                placeholder="اكتب نبذة قصيرة عن نفسك..."
                className="font-serif resize-none"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              إلغاء
            </Button>
            <Button
              onClick={handleUpdateProfile}
              disabled={updateProfileMutation.isPending}
            >
              {updateProfileMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              ) : null}
              حفظ التغييرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
