import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  ArrowRight,
  Bell,
  BellOff,
  Check,
  CheckCheck,
  FileText,
  MessageSquare,
  Shield,
  Loader2,
} from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const notificationIcons: Record<string, React.ReactNode> = {
  new_post: <FileText className="h-5 w-5" />,
  new_comment: <MessageSquare className="h-5 w-5" />,
  role_change: <Shield className="h-5 w-5" />,
  system: <Bell className="h-5 w-5" />,
};

const notificationColors: Record<string, string> = {
  new_post: "bg-blue-100 text-blue-600",
  new_comment: "bg-green-100 text-green-600",
  role_change: "bg-purple-100 text-purple-600",
  system: "bg-gray-100 text-gray-600",
};

export default function Notifications() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  const utils = trpc.useUtils();

  const { data: notifications, isLoading } = trpc.notifications.getMine.useQuery(
    undefined,
    { enabled: !!user }
  );

  const markAsReadMutation = trpc.notifications.markAsRead.useMutation({
    onSuccess: () => {
      utils.notifications.getMine.invalidate();
      utils.notifications.getUnreadCount.invalidate();
    },
  });

  const markAllAsReadMutation = trpc.notifications.markAllAsRead.useMutation({
    onSuccess: () => {
      utils.notifications.getMine.invalidate();
      utils.notifications.getUnreadCount.invalidate();
      toast.success("تم تعليم جميع الإشعارات كمقروءة");
    },
  });

  const handleNotificationClick = (notification: any) => {
    if (!notification.isRead) {
      markAsReadMutation.mutate({ id: notification.id });
    }
    if (notification.relatedPostId) {
      setLocation(`/post/${notification.relatedPostId}`);
    }
  };

  // Redirect to login if not authenticated
  if (!authLoading && !user) {
    window.location.href = "/login";
    return null;
  }

  const unreadCount = notifications?.filter((n) => !n.isRead).length || 0;

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation("/")}
        className="mb-6 gap-2"
      >
        <ArrowRight className="h-4 w-4" />
        العودة
      </Button>

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="small-caps text-muted-foreground mb-2">مركز الإشعارات</p>
          <h1 className="font-display text-3xl">الإشعارات</h1>
        </div>
        {unreadCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => markAllAsReadMutation.mutate()}
            disabled={markAllAsReadMutation.isPending}
            className="gap-2"
          >
            {markAllAsReadMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <CheckCheck className="h-4 w-4" />
            )}
            تعليم الكل كمقروء
          </Button>
        )}
      </div>

      {/* Unread Badge */}
      {unreadCount > 0 && (
        <div className="mb-6">
          <Badge variant="secondary" className="gap-1">
            <Bell className="h-3 w-3" />
            {unreadCount} إشعار غير مقروء
          </Badge>
        </div>
      )}

      {/* Notifications List */}
      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="editorial-card">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-5 w-3/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : notifications && notifications.length > 0 ? (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`editorial-card cursor-pointer transition-all ${
                !notification.isRead
                  ? "ring-2 ring-primary/20 bg-primary/5"
                  : ""
              }`}
              onClick={() => handleNotificationClick(notification)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div
                    className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${
                      notificationColors[notification.type]
                    }`}
                  >
                    {notificationIcons[notification.type]}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h3 className="font-medium line-clamp-1">
                        {notification.title}
                      </h3>
                      {!notification.isRead && (
                        <span className="h-2 w-2 bg-primary rounded-full shrink-0" />
                      )}
                    </div>
                    <p className="font-serif text-sm text-muted-foreground line-clamp-2">
                      {notification.message}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2 font-sans">
                      {new Date(notification.createdAt).toLocaleDateString("ar-SA", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="editorial-card">
          <CardContent className="py-16 text-center">
            <BellOff className="h-16 w-16 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="font-display text-xl mb-2">لا توجد إشعارات</h3>
            <p className="text-muted-foreground font-serif">
              ستظهر هنا الإشعارات الجديدة عند وصولها
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
