import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  ArrowRight,
  Calendar,
  Edit,
  Eye,
  FileIcon,
  Heart,
  Loader2,
  MessageSquare,
  Share2,
  Trash2,
  User,
  Download,
} from "lucide-react";
import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Streamdown } from "streamdown";

const categoryLabels: Record<string, { label: string; color: string }> = {
  announcement: { label: "إعلان", color: "bg-red-100 text-red-800" },
  lesson: { label: "درس", color: "bg-blue-100 text-blue-800" },
  activity: { label: "نشاط", color: "bg-green-100 text-green-800" },
  news: { label: "أخبار", color: "bg-purple-100 text-purple-800" },
  resource: { label: "مصدر", color: "bg-amber-100 text-amber-800" },
};

const roleLabels: Record<string, string> = {
  admin: "مدير",
  teacher: "معلم",
  student: "طالب",
};

export default function PostDetail() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const postId = parseInt(params.id);

  const [comment, setComment] = useState("");
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const utils = trpc.useUtils();

  const { data: post, isLoading } = trpc.posts.getById.useQuery({ id: postId });
  const { data: comments, refetch: refetchComments } =
    trpc.comments.getByPostId.useQuery({ postId });

  const likeMutation = trpc.likes.toggle.useMutation({
    onSuccess: () => {
      utils.posts.getById.invalidate({ id: postId });
    },
  });

  const commentMutation = trpc.comments.create.useMutation({
    onSuccess: () => {
      setComment("");
      refetchComments();
      toast.success("تم إضافة التعليق");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deletePostMutation = trpc.posts.delete.useMutation({
    onSuccess: () => {
      toast.success("تم حذف المنشور");
      setLocation("/");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteCommentMutation = trpc.comments.delete.useMutation({
    onSuccess: () => {
      refetchComments();
      toast.success("تم حذف التعليق");
    },
  });

  const handleLike = () => {
    if (!user) {
      window.location.href = "/login";
      return;
    }
    likeMutation.mutate({ postId });
  };

  const handleComment = () => {
    if (!user) {
      window.location.href = "/login";
      return;
    }
    if (!comment.trim()) {
      toast.error("يرجى كتابة تعليق");
      return;
    }
    commentMutation.mutate({ postId, content: comment });
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("تم نسخ الرابط");
  };

  const canEdit =
    user &&
    (user.role === "admin" || user.id === post?.author?.id);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <h2 className="font-display text-2xl mb-2">المنشور غير موجود</h2>
          <Button onClick={() => setLocation("/")}>العودة للرئيسية</Button>
        </div>
      </div>
    );
  }

  const category = categoryLabels[post.post.category];

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Back Button */}
      <Button
        variant="ghost"
        onClick={() => setLocation("/")}
        className="mb-6 gap-2"
      >
        <ArrowRight className="h-4 w-4" />
        العودة
      </Button>

      {/* Article Header */}
      <article>
        <header className="mb-8">
          {/* Category & Meta */}
          <div className="flex items-center gap-4 mb-4">
            <Badge className={category.color}>{category.label}</Badge>
            {post.post.isPinned && (
              <Badge variant="outline">مثبت</Badge>
            )}
          </div>

          {/* Title */}
          <h1 className="font-display text-4xl md:text-5xl mb-6 leading-tight">
            {post.post.title}
          </h1>

          {/* Author & Date */}
          <div className="flex items-center justify-between flex-wrap gap-4 pb-6 border-b border-border/50">
            <div className="flex items-center gap-4">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-secondary font-medium">
                  {post.author?.name?.charAt(0)?.toUpperCase() || "؟"}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{post.author?.name || "مجهول"}</p>
                <p className="text-sm text-muted-foreground">
                  {roleLabels[post.author?.role || "student"]}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {new Date(post.post.createdAt).toLocaleDateString("ar-SA", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {post.post.viewCount} مشاهدة
              </span>
            </div>
          </div>
        </header>

        {/* Featured Image */}
        {post.post.featuredImageUrl && (
          <div className="mb-8">
            <img
              src={post.post.featuredImageUrl}
              alt={post.post.title}
              className="w-full aspect-video object-cover rounded-lg"
            />
          </div>
        )}

        {/* Content */}
        <div className="prose-editorial text-lg leading-relaxed mb-8">
          <Streamdown>{post.post.content}</Streamdown>
        </div>

        {/* Attachments */}
        {post.attachments && post.attachments.length > 0 && (
          <Card className="editorial-card mb-8">
            <CardContent className="pt-6">
              <h3 className="font-display text-lg mb-4">المرفقات</h3>
              <div className="space-y-2">
                {post.attachments.map((att) => (
                  <a
                    key={att.id}
                    href={att.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg hover:bg-secondary transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <FileIcon className="h-5 w-5 text-muted-foreground" />
                      <span className="text-sm font-sans">{att.fileName}</span>
                    </div>
                    <Download className="h-4 w-4 text-muted-foreground" />
                  </a>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between py-6 border-y border-border/50">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className={`gap-2 ${post.likes.userLiked ? "text-red-500" : ""}`}
            >
              <Heart
                className={`h-5 w-5 ${post.likes.userLiked ? "fill-current" : ""}`}
              />
              <span>{post.likes.count}</span>
            </Button>
            <Button variant="ghost" size="sm" className="gap-2">
              <MessageSquare className="h-5 w-5" />
              <span>{post.commentsCount}</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={handleShare}>
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
          {canEdit && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation(`/edit/${post.post.id}`)}
              >
                <Edit className="h-4 w-4 ml-2" />
                تعديل
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setShowDeleteDialog(true)}
              >
                <Trash2 className="h-4 w-4 ml-2" />
                حذف
              </Button>
            </div>
          )}
        </div>
      </article>

      {/* Comments Section */}
      <section className="mt-12">
        <h2 className="font-display text-2xl mb-6">
          التعليقات ({comments?.length || 0})
        </h2>

        {/* Comment Form */}
        <Card className="editorial-card mb-8">
          <CardContent className="pt-6">
            {user ? (
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-secondary">
                      {user.name?.charAt(0)?.toUpperCase() || "؟"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="اكتب تعليقك..."
                      className="font-serif resize-none"
                      rows={3}
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button
                    onClick={handleComment}
                    disabled={commentMutation.isPending}
                  >
                    {commentMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin ml-2" />
                    ) : null}
                    إرسال التعليق
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-muted-foreground mb-4 font-serif">
                  يجب تسجيل الدخول للتعليق
                </p>
                <Button onClick={() => (window.location.href = getLoginUrl())}>
                  تسجيل الدخول
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comments List */}
        <div className="space-y-6">
          {comments?.map(({ comment: c, author }) => (
            <Card key={c.id} className="editorial-card">
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-secondary">
                      {author?.name?.charAt(0)?.toUpperCase() || "؟"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">
                          {author?.name || "مجهول"}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {roleLabels[author?.role || "student"]}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">
                          {new Date(c.createdAt).toLocaleDateString("ar-SA")}
                        </span>
                        {user &&
                          (user.role === "admin" || user.id === author?.id) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                deleteCommentMutation.mutate({ id: c.id })
                              }
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          )}
                      </div>
                    </div>
                    <p className="font-serif text-foreground/90">{c.content}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {(!comments || comments.length === 0) && (
            <div className="text-center py-12">
              <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
              <p className="text-muted-foreground font-serif">
                لا توجد تعليقات بعد. كن أول من يعلق!
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Delete Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display">
              حذف المنشور
            </AlertDialogTitle>
            <AlertDialogDescription className="font-serif">
              هل أنت متأكد من حذف هذا المنشور؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletePostMutation.mutate({ id: postId })}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
