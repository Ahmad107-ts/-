import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowRight, Image, Loader2, Upload, X, FileIcon } from "lucide-react";
import { useCallback, useState } from "react";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";

const categories = [
  { value: "announcement", label: "إعلان", color: "bg-red-100 text-red-800" },
  { value: "lesson", label: "درس", color: "bg-blue-100 text-blue-800" },
  { value: "activity", label: "نشاط", color: "bg-green-100 text-green-800" },
  { value: "news", label: "أخبار", color: "bg-purple-100 text-purple-800" },
  { value: "resource", label: "مصدر", color: "bg-amber-100 text-amber-800" },
];

export default function CreatePost() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const params = useParams<{ id?: string }>();
  const isEditing = !!params.id;

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [category, setCategory] = useState<string>("announcement");
  const [audience, setAudience] = useState<string>("all");
  const [isPinned, setIsPinned] = useState(false);
  const [featuredImage, setFeaturedImage] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [attachments, setAttachments] = useState<Array<{ name: string; url: string; type: string }>>([]);

  // Load post data if editing
  const { data: existingPost, isLoading: loadingPost } = trpc.posts.getById.useQuery(
    { id: parseInt(params.id || "0") },
    { enabled: isEditing }
  );

  // Set form data when editing
  useState(() => {
    if (existingPost) {
      setTitle(existingPost.post.title);
      setContent(existingPost.post.content);
      setExcerpt(existingPost.post.excerpt || "");
      setCategory(existingPost.post.category);
      setAudience(existingPost.post.audience || "all");
      setIsPinned(existingPost.post.isPinned);
      setFeaturedImage(existingPost.post.featuredImageUrl);
      if (existingPost.attachments) {
        setAttachments(
          existingPost.attachments.map((a) => ({
            name: a.fileName,
            url: a.fileUrl,
            type: a.fileType || "",
          }))
        );
      }
    }
  });

  const uploadImageMutation = trpc.upload.image.useMutation();

  const createPostMutation = trpc.posts.create.useMutation({
    onSuccess: (data) => {
      toast.success("تم نشر المنشور بنجاح");
      setLocation(`/post/${data.id}`);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const updatePostMutation = trpc.posts.update.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث المنشور بنجاح");
      setLocation(`/post/${params.id}`);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleImageUpload = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) {
        toast.error("يرجى اختيار صورة صالحة");
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast.error("حجم الصورة يجب أن يكون أقل من 5 ميجابايت");
        return;
      }

      setUploadingImage(true);
      try {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = (reader.result as string).split(",")[1];
          const result = await uploadImageMutation.mutateAsync({
            fileName: file.name,
            fileData: base64,
            fileType: file.type,
          });
          setFeaturedImage(result.url);
          setUploadingImage(false);
        };
        reader.readAsDataURL(file);
      } catch (error) {
        toast.error("فشل في رفع الصورة");
        setUploadingImage(false);
      }
    },
    [uploadImageMutation]
  );

  const handleAttachmentUpload = useCallback(
    async (file: File) => {
      if (file.size > 10 * 1024 * 1024) {
        toast.error("حجم الملف يجب أن يكون أقل من 10 ميجابايت");
        return;
      }

      try {
        const reader = new FileReader();
        reader.onload = async () => {
          const base64 = (reader.result as string).split(",")[1];
          const result = await uploadImageMutation.mutateAsync({
            fileName: file.name,
            fileData: base64,
            fileType: file.type,
          });
          setAttachments((prev) => [
            ...prev,
            { name: file.name, url: result.url, type: file.type },
          ]);
        };
        reader.readAsDataURL(file);
      } catch (error) {
        toast.error("فشل في رفع الملف");
      }
    },
    [uploadImageMutation]
  );

  const handleSubmit = () => {
    if (!title.trim()) {
      toast.error("يرجى إدخال عنوان المنشور");
      return;
    }
    if (!content.trim()) {
      toast.error("يرجى إدخال محتوى المنشور");
      return;
    }

    const postData = {
      title,
      content,
      excerpt: excerpt || undefined,
      category: category as "announcement" | "lesson" | "activity" | "news" | "resource",
      audience: audience as "admin" | "teacher" | "student" | "all",
      isPinned,
      featuredImageUrl: featuredImage || undefined,
    };

    if (isEditing) {
      updatePostMutation.mutate({ id: parseInt(params.id!), ...postData });
    } else {
      createPostMutation.mutate(postData);
    }
  };

  // Check authorization
  if (!user || (user.role !== "admin" && user.role !== "teacher")) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <h2 className="font-display text-2xl mb-2">غير مصرح</h2>
          <p className="text-muted-foreground font-serif">
            هذه الصفحة متاحة للمعلمين والمديرين فقط
          </p>
        </div>
      </div>
    );
  }

  if (isEditing && loadingPost) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <Button
          variant="ghost"
          onClick={() => setLocation("/")}
          className="mb-4 gap-2"
        >
          <ArrowRight className="h-4 w-4" />
          العودة
        </Button>
        <p className="small-caps text-muted-foreground mb-2">
          {isEditing ? "تحرير المنشور" : "منشور جديد"}
        </p>
        <h1 className="font-display text-4xl">
          {isEditing ? "تعديل المنشور" : "إنشاء منشور جديد"}
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="editorial-card">
            <CardContent className="pt-6 space-y-6">
              {/* Title */}
              <div className="space-y-2">
                <Label htmlFor="title" className="font-sans">
                  العنوان
                </Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="أدخل عنوان المنشور..."
                  className="font-display text-xl h-12"
                />
              </div>

              {/* Excerpt */}
              <div className="space-y-2">
                <Label htmlFor="excerpt" className="font-sans">
                  الملخص (اختياري)
                </Label>
                <Textarea
                  id="excerpt"
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  placeholder="ملخص قصير للمنشور..."
                  className="font-serif resize-none"
                  rows={2}
                />
              </div>

              {/* Content */}
              <div className="space-y-2">
                <Label htmlFor="content" className="font-sans">
                  المحتوى
                </Label>
                <Textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="اكتب محتوى المنشور هنا..."
                  className="font-serif min-h-[300px] resize-none"
                />
                <p className="text-xs text-muted-foreground font-sans">
                  يمكنك استخدام تنسيق Markdown للنص
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Attachments */}
          <Card className="editorial-card">
            <CardHeader>
              <CardTitle className="font-display text-lg">المرفقات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div
                className="border-2 border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => {
                  const input = document.createElement("input");
                  input.type = "file";
                  input.accept = ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip";
                  input.onchange = (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0];
                    if (file) handleAttachmentUpload(file);
                  };
                  input.click();
                }}
              >
                <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground font-sans">
                  اضغط لرفع ملف (PDF, Word, Excel, PowerPoint)
                </p>
              </div>

              {attachments.length > 0 && (
                <div className="space-y-2">
                  {attachments.map((att, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 bg-secondary/50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <FileIcon className="h-5 w-5 text-muted-foreground" />
                        <span className="text-sm font-sans">{att.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() =>
                          setAttachments((prev) =>
                            prev.filter((_, i) => i !== index)
                          )
                        }
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Featured Image */}
          <Card className="editorial-card">
            <CardHeader>
              <CardTitle className="font-display text-lg">الصورة الرئيسية</CardTitle>
            </CardHeader>
            <CardContent>
              {featuredImage ? (
                <div className="relative">
                  <img
                    src={featuredImage}
                    alt="Featured"
                    className="w-full aspect-video object-cover rounded-lg"
                  />
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 left-2"
                    onClick={() => setFeaturedImage(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div
                  className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                  onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file";
                    input.accept = "image/*";
                    input.onchange = (e) => {
                      const file = (e.target as HTMLInputElement).files?.[0];
                      if (file) handleImageUpload(file);
                    };
                    input.click();
                  }}
                >
                  {uploadingImage ? (
                    <Loader2 className="h-8 w-8 mx-auto animate-spin text-primary" />
                  ) : (
                    <>
                      <Image className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground font-sans">
                        اضغط لرفع صورة
                      </p>
                    </>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Settings */}
          <Card className="editorial-card">
            <CardHeader>
              <CardTitle className="font-display text-lg">الإعدادات</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Category */}
              <div className="space-y-2">
                <Label className="font-sans">التصنيف</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="font-sans">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        <span className={`px-2 py-0.5 rounded text-xs ${cat.color}`}>
                          {cat.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Audience */}
              <div className="space-y-2">
                <Label className="font-sans">الجمهور المستهدف</Label>
                <Select value={audience} onValueChange={setAudience}>
                  <SelectTrigger className="font-sans">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">الجميع</SelectItem>
                    <SelectItem value="admin">المدير فقط</SelectItem>
                    <SelectItem value="teacher">المعلمون فقط</SelectItem>
                    <SelectItem value="student">الطلاب فقط</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Pin Post */}
              {user.role === "admin" && (
                <div className="flex items-center justify-between">
                  <Label htmlFor="pinned" className="font-sans">
                    تثبيت المنشور
                  </Label>
                  <Switch
                    id="pinned"
                    checked={isPinned}
                    onCheckedChange={setIsPinned}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Actions */}
          <Card className="editorial-card">
            <CardContent className="pt-6">
              <Button
                className="w-full"
                size="lg"
                onClick={handleSubmit}
                disabled={
                  createPostMutation.isPending || updatePostMutation.isPending
                }
              >
                {createPostMutation.isPending || updatePostMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin ml-2" />
                    جارٍ الحفظ...
                  </>
                ) : isEditing ? (
                  "تحديث المنشور"
                ) : (
                  "نشر المنشور"
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
