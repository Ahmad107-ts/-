import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import {
  ArrowLeft,
  Bell,
  Calendar,
  Heart,
  MessageSquare,
  PenSquare,
  Pin,
  Search,
  Eye,
  School,
} from "lucide-react";
import { useState } from "react";
import { Link, useLocation, Redirect } from "wouter";

const categoryLabels: Record<string, { label: string; color: string }> = {
  announcement: { label: "إعلان", color: "bg-red-100 text-red-800" },
  lesson: { label: "درس", color: "bg-blue-100 text-blue-800" },
  activity: { label: "نشاط", color: "bg-green-100 text-green-800" },
  news: { label: "أخبار", color: "bg-purple-100 text-purple-800" },
  resource: { label: "مصدر", color: "bg-amber-100 text-amber-800" },
};

function PostCardSkeleton() {
  return (
    <Card className="editorial-card">
      <CardContent className="p-6">
        <Skeleton className="h-4 w-20 mb-4" />
        <Skeleton className="h-8 w-3/4 mb-3" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-2/3 mb-4" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Skeleton className="h-8 w-8 rounded-full" />
            <Skeleton className="h-4 w-24" />
          </div>
          <Skeleton className="h-4 w-16" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const { data: posts, isLoading } = trpc.posts.getAll.useQuery({
    category: categoryFilter !== "all" ? categoryFilter : undefined,
    search: searchQuery || undefined,
  });

  const { data: unreadCount } = trpc.notifications.getUnreadCount.useQuery(
    undefined,
    { enabled: !!user }
  );

  const canCreatePost = user && (user.role === "admin" || user.role === "teacher");

  // Get pinned posts
  const pinnedPosts = posts?.filter((p) => p.post.isPinned) || [];
  const regularPosts = posts?.filter((p) => !p.post.isPinned) || [];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3">
              <div className="h-10 w-10 bg-primary rounded-lg flex items-center justify-center">
                <School className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="font-display text-lg">مدرسة زوبيا الثانوية</h1>
                <p className="text-xs text-muted-foreground font-sans">الشاملة للبنين</p>
              </div>
            </Link>

            {/* Actions */}
            <div className="flex items-center gap-3">
              {user ? (
                <>
                  {/* Notifications */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="relative"
                    onClick={() => setLocation("/notifications")}
                  >
                    <Bell className="h-5 w-5" />
                    {unreadCount && unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 h-5 w-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
                        {unreadCount > 9 ? "9+" : unreadCount}
                      </span>
                    )}
                  </Button>

                  {/* Create Post */}
                  {canCreatePost && (
                    <Button onClick={() => setLocation("/create")} className="gap-2">
                      <PenSquare className="h-4 w-4" />
                      <span className="hidden sm:inline">منشور جديد</span>
                    </Button>
                  )}

                  {/* Profile */}
                  <Button
                    variant="ghost"
                    className="gap-2"
                    onClick={() => setLocation("/profile")}
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-secondary text-sm">
                        {user.name?.charAt(0)?.toUpperCase() || "؟"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline font-medium">{user.name}</span>
                  </Button>

                  {/* Admin Dashboard */}
                  {user.role === "admin" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLocation("/admin")}
                    >
                      لوحة التحكم
                    </Button>
                  )}
                </>
              ) : (
                <Button onClick={() => setLocation("/login")}>
                  تسجيل الدخول
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 border-b border-border/30">
        <div className="container">
          <div className="max-w-3xl">
            <p className="subheading-elegant text-muted-foreground mb-4">
              مرحباً بكم في
            </p>
            <h1 className="headline-massive mb-6">
              مدرسة زوبيا
              <br />
              <span className="text-primary">الثانوية الشاملة</span>
            </h1>
            <p className="font-serif text-xl text-muted-foreground leading-relaxed max-w-2xl">
              منصة تعليمية متكاملة تجمع بين المعلمين والطلاب في بيئة تفاعلية آمنة.
              تابع آخر الإعلانات والدروس والأنشطة المدرسية.
            </p>
          </div>
        </div>
      </section>

      {/* Search & Filter */}
      <section className="py-8 border-b border-border/30">
        <div className="container">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث في المنشورات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 font-sans"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full sm:w-[180px] font-sans">
                <SelectValue placeholder="جميع التصنيفات" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع التصنيفات</SelectItem>
                <SelectItem value="announcement">الإعلانات</SelectItem>
                <SelectItem value="lesson">الدروس</SelectItem>
                <SelectItem value="activity">الأنشطة</SelectItem>
                <SelectItem value="news">الأخبار</SelectItem>
                <SelectItem value="resource">المصادر</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="py-12">
        <div className="container">
          {/* Pinned Posts */}
          {pinnedPosts.length > 0 && (
            <section className="mb-12">
              <div className="flex items-center gap-2 mb-6">
                <Pin className="h-5 w-5 text-primary" />
                <h2 className="font-display text-2xl">منشورات مثبتة</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {pinnedPosts.map(({ post, author, likes, commentsCount }) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    author={author}
                    likes={likes}
                    commentsCount={commentsCount}
                    isPinned
                  />
                ))}
              </div>
            </section>
          )}

          {/* All Posts */}
          <section>
            <h2 className="font-display text-2xl mb-6">آخر المنشورات</h2>
            
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <PostCardSkeleton key={i} />
                ))}
              </div>
            ) : regularPosts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {regularPosts.map(({ post, author, likes, commentsCount }) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    author={author}
                    likes={likes}
                    commentsCount={commentsCount}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="h-24 w-24 mx-auto bg-secondary/50 rounded-full flex items-center justify-center mb-6">
                  <PenSquare className="h-10 w-10 text-muted-foreground" />
                </div>
                <h3 className="font-display text-xl mb-2">لا توجد منشورات</h3>
                <p className="text-muted-foreground font-serif">
                  {searchQuery || categoryFilter !== "all"
                    ? "لم يتم العثور على منشورات تطابق البحث"
                    : "لم يتم نشر أي محتوى بعد"}
                </p>
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground font-sans">
              © {new Date().getFullYear()} مدرسة زوبيا الثانوية الشاملة للبنين. جميع الحقوق محفوظة.
            </p>
            <div className="flex items-center gap-6">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                عن المدرسة
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                تواصل معنا
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Post Card Component
function PostCard({
  post,
  author,
  likes,
  commentsCount,
  isPinned = false,
}: {
  post: any;
  author: any;
  likes: { count: number; userLiked: boolean };
  commentsCount: number;
  isPinned?: boolean;
}) {
  const category = categoryLabels[post.category];

  return (
    <Link href={`/post/${post.id}`}>
      <Card className={`editorial-card h-full cursor-pointer group ${isPinned ? "ring-2 ring-primary/20" : ""}`}>
        {/* Featured Image */}
        {post.featuredImageUrl && (
          <div className="aspect-video overflow-hidden">
            <img
              src={post.featuredImageUrl}
              alt={post.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </div>
        )}
        
        <CardContent className="p-6">
          {/* Category & Pin Badge */}
          <div className="flex items-center gap-2 mb-3">
            <Badge className={`${category.color} text-xs`}>{category.label}</Badge>
            {isPinned && (
              <Badge variant="outline" className="text-xs gap-1">
                <Pin className="h-3 w-3" />
                مثبت
              </Badge>
            )}
          </div>

          {/* Title */}
          <h3 className="font-display text-xl mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {post.title}
          </h3>

          {/* Excerpt */}
          {post.excerpt && (
            <p className="font-serif text-muted-foreground text-sm line-clamp-2 mb-4">
              {post.excerpt}
            </p>
          )}

          {/* Meta */}
          <div className="flex items-center justify-between pt-4 border-t border-border/50">
            <div className="flex items-center gap-2">
              <Avatar className="h-7 w-7">
                <AvatarFallback className="bg-secondary text-xs">
                  {author?.name?.charAt(0)?.toUpperCase() || "؟"}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{author?.name || "مجهول"}</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Heart className={`h-3.5 w-3.5 ${likes.userLiked ? "fill-red-500 text-red-500" : ""}`} />
                {likes.count}
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare className="h-3.5 w-3.5" />
                {commentsCount}
              </span>
            </div>
          </div>

          {/* Date */}
          <div className="flex items-center gap-1 text-xs text-muted-foreground mt-3">
            <Calendar className="h-3 w-3" />
            {new Date(post.createdAt).toLocaleDateString("ar-SA")}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
