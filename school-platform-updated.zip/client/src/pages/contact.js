
import { useState } from "react";

export default function Contact() {
  const [form, setForm] = useState({
    question: "",
    phone: "",
    subject: "",
    student: "",
    teacher: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const requests = JSON.parse(localStorage.getItem("contactRequests") || "[]");
    requests.push({ ...form, date: new Date().toISOString() });
    localStorage.setItem("contactRequests", JSON.stringify(requests));

    window.location.href =
      "mailto:admin@school.com?subject=طلب تواصل جديد&body=" +
      encodeURIComponent(
        `السؤال: ${form.question}\nالهاتف: ${form.phone}\nالمادة والفصل: ${form.subject}\nاسم الطالب: ${form.student}\nاسم الأستاذ: ${form.teacher}`
      );

    alert("تم إرسال الطلب إلى المدير");
    setForm({ question: "", phone: "", subject: "", student: "", teacher: "" });
  };

  return (
    <div style={{ padding: 30, maxWidth: 600, margin: "auto" }}>
      <h1>تواصل معنا</h1>
      <form onSubmit={handleSubmit}>
        <input name="question" placeholder="السؤال" value={form.question} onChange={handleChange} required /><br/><br/>
        <input name="phone" placeholder="رقم الهاتف" value={form.phone} onChange={handleChange} required /><br/><br/>
        <input name="subject" placeholder="المادة والفصل" value={form.subject} onChange={handleChange} required /><br/><br/>
        <input name="student" placeholder="اسم الطالب" value={form.student} onChange={handleChange} required /><br/><br/>
        <input name="teacher" placeholder="اسم الأستاذ" value={form.teacher} onChange={handleChange} required /><br/><br/>
        <button type="submit">إرسال</button>
      </form>
    </div>
  );
}
