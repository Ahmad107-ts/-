import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { FileText, MessageSquare, Search, Users, UserCog, Shield, GraduationCap, BookOpen } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const roleLabels: Record<string, string> = {
  admin: "مدير",
  teacher: "معلم",
  student: "طالب",
};

const roleIcons: Record<string, React.ReactNode> = {
  admin: <Shield className="h-3 w-3" />,
  teacher: <BookOpen className="h-3 w-3" />,
  student: <GraduationCap className="h-3 w-3" />,
};

export default function AdminDashboard() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [newRole, setNewRole] = useState<string>("");

  const { data: stats } = trpc.users.getStats.useQuery();
  const { data: users, refetch: refetchUsers } = trpc.users.getAll.useQuery({
    role: roleFilter !== "all" ? roleFilter : undefined,
    search: searchQuery || undefined,
  });

  const updateRoleMutation = trpc.users.updateRole.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث الدور بنجاح");
      refetchUsers();
      setSelectedUser(null);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const toggleActiveMutation = trpc.users.toggleActive.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث حالة المستخدم");
      refetchUsers();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleRoleChange = () => {
    if (selectedUser && newRole) {
      updateRoleMutation.mutate({
        userId: selectedUser.id,
        role: newRole as "admin" | "teacher" | "student",
      });
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <Shield className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="font-display text-2xl mb-2">غير مصرح</h2>
          <p className="text-muted-foreground font-serif">
            هذه الصفحة متاحة للمديرين فقط
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="border-b border-border/50 pb-6">
        <p className="small-caps text-muted-foreground mb-2">لوحة التحكم</p>
        <h1 className="font-display text-4xl">إدارة المستخدمين</h1>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="editorial-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-sans font-medium text-muted-foreground">
              إجمالي المستخدمين
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display">{stats?.users || 0}</div>
          </CardContent>
        </Card>

        <Card className="editorial-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-sans font-medium text-muted-foreground">
              المنشورات
            </CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display">{stats?.posts || 0}</div>
          </CardContent>
        </Card>

        <Card className="editorial-card">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-sans font-medium text-muted-foreground">
              التعليقات
            </CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-display">{stats?.comments || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="البحث عن مستخدم..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 font-sans"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-[180px] font-sans">
            <SelectValue placeholder="تصفية حسب الدور" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الأدوار</SelectItem>
            <SelectItem value="admin">المديرون</SelectItem>
            <SelectItem value="teacher">المعلمون</SelectItem>
            <SelectItem value="student">الطلاب</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Users Table */}
      <Card className="editorial-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right font-sans">المستخدم</TableHead>
              <TableHead className="text-right font-sans">البريد الإلكتروني</TableHead>
              <TableHead className="text-right font-sans">الدور</TableHead>
              <TableHead className="text-right font-sans">الحالة</TableHead>
              <TableHead className="text-right font-sans">تاريخ الانضمام</TableHead>
              <TableHead className="text-right font-sans">الإجراءات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users?.map((u) => (
              <TableRow key={u.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="text-xs font-medium bg-secondary">
                        {u.name?.charAt(0)?.toUpperCase() || "؟"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium">{u.name || "بدون اسم"}</span>
                  </div>
                </TableCell>
                <TableCell className="font-sans text-sm text-muted-foreground">
                  {u.email || "-"}
                </TableCell>
                <TableCell>
                  <Badge
                    variant="secondary"
                    className={`gap-1 ${
                      u.role === "admin"
                        ? "bg-primary/10 text-primary"
                        : u.role === "teacher"
                        ? "bg-blue-100 text-blue-700"
                        : "bg-emerald-100 text-emerald-700"
                    }`}
                  >
                    {roleIcons[u.role]}
                    {roleLabels[u.role]}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={u.isActive ? "default" : "secondary"}>
                    {u.isActive ? "نشط" : "معطل"}
                  </Badge>
                </TableCell>
                <TableCell className="font-sans text-sm text-muted-foreground">
                  {new Date(u.createdAt).toLocaleDateString("ar-SA")}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(u);
                        setNewRole(u.role);
                      }}
                      disabled={u.id === user?.id}
                    >
                      <UserCog className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        toggleActiveMutation.mutate({
                          userId: u.id,
                          isActive: !u.isActive,
                        })
                      }
                      disabled={u.id === user?.id}
                    >
                      {u.isActive ? "تعطيل" : "تفعيل"}
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Role Change Dialog */}
      <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">تغيير دور المستخدم</DialogTitle>
            <DialogDescription className="font-serif">
              تغيير دور {selectedUser?.name || "المستخدم"}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Select value={newRole} onValueChange={setNewRole}>
              <SelectTrigger className="font-sans">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">مدير</SelectItem>
                <SelectItem value="teacher">معلم</SelectItem>
                <SelectItem value="student">طالب</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedUser(null)}>
              إلغاء
            </Button>
            <Button
              onClick={handleRoleChange}
              disabled={updateRoleMutation.isPending}
            >
              {updateRoleMutation.isPending ? "جارٍ الحفظ..." : "حفظ التغييرات"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
