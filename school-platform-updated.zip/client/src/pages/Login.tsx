import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { getLoginUrl } from "@/const";
import { BookOpen, GraduationCap, Shield, School, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

// Access codes for verification (in production, these should be stored securely on the server)
const ACCESS_CODES = {
  admin: "ADMIN2024",
  teacher: "TEACHER2024", 
  student: "STUDENT2024",
};

const roleInfo = {
  admin: {
    label: "مدير",
    icon: Shield,
    description: "الوصول الكامل لإدارة المنصة والمستخدمين",
    color: "bg-primary/10 text-primary border-primary/20",
  },
  teacher: {
    label: "معلم",
    icon: BookOpen,
    description: "نشر الدروس والإعلانات والتفاعل مع الطلاب",
    color: "bg-blue-100 text-blue-700 border-blue-200",
  },
  student: {
    label: "طالب",
    icon: GraduationCap,
    description: "متابعة المحتوى والتفاعل مع المنشورات",
    color: "bg-emerald-100 text-emerald-700 border-emerald-200",
  },
};

export default function Login() {
  const [step, setStep] = useState<"role" | "verify">("role");
  const [selectedRole, setSelectedRole] = useState<"admin" | "teacher" | "student" | null>(null);
  const [accessCode, setAccessCode] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);

  const handleRoleSelect = (role: "admin" | "teacher" | "student") => {
    setSelectedRole(role);
    setStep("verify");
    setAccessCode("");
  };

  const handleVerify = () => {
    if (!selectedRole || !accessCode.trim()) {
      toast.error("يرجى إدخال رمز الوصول");
      return;
    }

    setIsVerifying(true);

    // Simulate verification delay
    setTimeout(() => {
      const expectedCode = ACCESS_CODES[selectedRole];
      
      if (accessCode.toUpperCase() === expectedCode) {
        // Store the selected role in sessionStorage for later use
        sessionStorage.setItem("pendingRole", selectedRole);
        // Redirect to OAuth login
        window.location.href = getLoginUrl();
      } else {
        toast.error("رمز الوصول غير صحيح. يرجى التحقق والمحاولة مرة أخرى.");
        setIsVerifying(false);
      }
    }, 500);
  };

  const handleBack = () => {
    setStep("role");
    setSelectedRole(null);
    setAccessCode("");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border/50 py-4">
        <div className="container">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 bg-primary rounded-lg flex items-center justify-center">
              <School className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-xl">مدرسة زوبيا الثانوية الشاملة للبنين</h1>
              <p className="text-xs text-muted-foreground font-sans">المنصة التعليمية التفاعلية</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-lg">
          {step === "role" ? (
            <div className="space-y-6">
              {/* Welcome Text */}
              <div className="text-center mb-8">
                <p className="subheading-elegant text-muted-foreground mb-3">مرحباً بك في</p>
                <h2 className="font-display text-3xl md:text-4xl mb-4">
                  منصة المدرسة التعليمية
                </h2>
                <p className="font-serif text-muted-foreground">
                  يرجى اختيار نوع حسابك للمتابعة
                </p>
              </div>

              {/* Role Selection Cards */}
              <div className="space-y-4">
                {(Object.keys(roleInfo) as Array<keyof typeof roleInfo>).map((role) => {
                  const info = roleInfo[role];
                  const Icon = info.icon;
                  
                  return (
                    <Card
                      key={role}
                      className={`editorial-card cursor-pointer transition-all hover:scale-[1.02] border-2 ${
                        selectedRole === role ? info.color : "border-transparent"
                      }`}
                      onClick={() => handleRoleSelect(role)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center gap-4">
                          <div className={`h-14 w-14 rounded-xl flex items-center justify-center ${info.color}`}>
                            <Icon className="h-7 w-7" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-display text-xl mb-1">{info.label}</h3>
                            <p className="text-sm text-muted-foreground font-serif">
                              {info.description}
                            </p>
                          </div>
                          <ArrowLeft className="h-5 w-5 text-muted-foreground" />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          ) : (
            <Card className="editorial-card">
              <CardHeader className="text-center">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBack}
                  className="absolute right-4 top-4"
                >
                  رجوع
                </Button>
                {selectedRole && (
                  <div className={`h-16 w-16 mx-auto rounded-xl flex items-center justify-center mb-4 ${roleInfo[selectedRole].color}`}>
                    {(() => {
                      const Icon = roleInfo[selectedRole].icon;
                      return <Icon className="h-8 w-8" />;
                    })()}
                  </div>
                )}
                <CardTitle className="font-display text-2xl">
                  تسجيل الدخول كـ {selectedRole && roleInfo[selectedRole].label}
                </CardTitle>
                <CardDescription className="font-serif">
                  أدخل رمز الوصول الخاص بك للتحقق من هويتك
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="accessCode" className="font-sans">رمز الوصول</Label>
                  <Input
                    id="accessCode"
                    type="password"
                    value={accessCode}
                    onChange={(e) => setAccessCode(e.target.value)}
                    placeholder="أدخل رمز الوصول..."
                    className="text-center text-lg tracking-widest"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleVerify();
                    }}
                  />
                  <p className="text-xs text-muted-foreground text-center font-sans">
                    رمز الوصول يتم الحصول عليه من إدارة المدرسة
                  </p>
                </div>

                <Button
                  className="w-full"
                  size="lg"
                  onClick={handleVerify}
                  disabled={isVerifying || !accessCode.trim()}
                >
                  {isVerifying ? "جارٍ التحقق..." : "تسجيل الدخول"}
                </Button>

                <div className="text-center">
                  <p className="text-sm text-muted-foreground font-serif">
                    ليس لديك رمز وصول؟{" "}
                    <span className="text-primary">تواصل مع إدارة المدرسة</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-4">
        <div className="container">
          <p className="text-center text-sm text-muted-foreground font-sans">
            © {new Date().getFullYear()} مدرسة زوبيا الثانوية الشاملة للبنين. جميع الحقوق محفوظة.
          </p>
        </div>
      </footer>
    </div>
  );
}
